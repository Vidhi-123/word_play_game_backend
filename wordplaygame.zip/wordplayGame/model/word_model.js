var db=require('../dbconnection');
var word={

    getAllWords:function(callback){
        return db.query("select * from word_tbl ORDER BY w_rating DESC",callback);
    },
    addWord:function(item,callback){
        return db.query("insert into word_tbl values(?,?,?,?)",[item.w_id,item.u_id,item.w_name,item.w_rating],callback);
    },
    deleteWord:function(id,callback){
        return db.query("delete from word_tbl where w_id=?",[id],callback);
    },
    getCntAvgByWorduser:function(id,callback){
        return db.query("select word_tbl.*, user_tbl.*,COUNT(word_tbl.u_id),AVG(word_tbl.w_rating) from word_tbl JOIN user_tbl ON user_tbl.u_id=word_tbl.u_id where word_tbl.u_id=?",[id],callback);
    }
};
module.exports=word;